import "./App.css";
import Main from "./components/main";
function App() {
	return (
		<div>
			<h1>Hello!</h1>
			<h2>Manage your finances effortlessly! 💸 </h2>
			<Main />
		</div>
	);
}

export default App;
